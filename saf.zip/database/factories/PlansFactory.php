<?php

use Faker\Generator as Faker;

$factory->define(App\Plans::class, function (Faker $faker) {
    return [
        'plan_name' => $faker->name,
        'with_sim' => rand(0,1),
        'with_device' => rand(0,1),
        'msf' => rand(1111,9999),
    ];
});
