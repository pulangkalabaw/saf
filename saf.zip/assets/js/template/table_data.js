$(document).ready(function() {
	var table = $('.datatable').DataTable({	ordering: true });
});
